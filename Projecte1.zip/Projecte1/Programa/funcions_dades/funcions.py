import funcions_dades.dades

# Hace falta una funcion que pueda limpiar la pantalla.


def getOpt(textOpts="", inputOptText="", rangeList=[], exceptions=[]):  # 1)
    while True:
        print(textOpts)
        opc = input(inputOptText)
        try:
            opc = int(opc)
            if opc in rangeList:
                return opc
            elif opc in exceptions:
                return opc
            else:
                print("="*65 + "Incorrect option" + "=" *65)
                input("Press enter to continue".center(146))
        except:
            if opc in exceptions:
                return opc
            else:
                print("="*65 + "Incorrect option" + "=" *65)
                input("Press enter to continue".center(146))
